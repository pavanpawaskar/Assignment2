import React from 'react';

function TodoItem({ todo, toggleComplete, deleteTodo }) {
  return (
    <div className="todo-item">
      <div style={{ display: 'flex', gap: '10px' }}>
        <input 
          type="checkbox" 
          checked={todo.completed} 
          onChange={() => toggleComplete(todo.id)}
        />
        
        <span className={todo.completed ? 'completed' : ''}>
          {todo.text}
        </span>
      </div>
      
      <button 
        className="delete-btn" 
        onClick={() => deleteTodo(todo.id)}
      >
        Delete
      </button>
    </div>
  );
}

export default TodoItem;