import React, { useState } from 'react';

function TodoInput({ addTodo }) {
  const [inputValue, setInputValue] = useState('');

  const handleAddClick = () => {
    if (inputValue.trim() === '') return; 
    
   
    addTodo(inputValue);
    
 
    setInputValue('');
  };

  return (
    <div className="input-container">
      <input 
        type="text" 
        className="input-field"
        placeholder="Add a new task..." 
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
      />
      <button onClick={handleAddClick}>Add</button>
    </div>
  );
}

export default TodoInput;