import React, { useState, useEffect } from 'react';
import './App.css';
import TodoInput from './TodoInput';
import TodoList from './TodoList';

function App() {
 
  const [todos, setTodos] = useState([]);

  
  useEffect(() => {
    const remainingTasks = todos.filter(t => !t.completed).length;
    document.title = `Todo App (${remainingTasks} left)`;
    console.log("Tasks updated:", todos);
  }, [todos]); 

  
  const addTodo = (text) => {
    const newTodo = {
      id: Date.now(), 
      text: text,
      completed: false
    };
    
    setTodos([...todos, newTodo]);
  };

  
  const toggleComplete = (id) => {
    setTodos(todos.map(todo => {
      if (todo.id === id) {
        return { ...todo, completed: !todo.completed }; 
      }
      return todo;
    }));
  };

  
  const deleteTodo = (id) => {
    setTodos(todos.filter(todo => todo.id !== id));
  };

  return (
    <div className="app-container">
      <h1>My Todo List</h1>
      
    
      <TodoInput addTodo={addTodo} />
      
    
      <TodoList 
        todos={todos} 
        toggleComplete={toggleComplete} 
        deleteTodo={deleteTodo} 
      />
    </div>
  );
}

export default App;